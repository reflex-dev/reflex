
class State:
    val = 20

    def __init__(self):
        self._init_mutable_fields()

    def _init_mutable_fields(self):
          val = _convert_mutable_datatypes()
          print(f"val: {val}")

    def random(self):
        a = _convert_mutable_datatypes()
        print(a + 3)

    def add(self):
        v = _convert_mutable_datatypes()
        self.val += v
        print(f"self.val : {self.val}")

    def __setattr__(self, key, value):

        c = _convert_mutable_datatypes()
        print(f"c here: {c}")
        super().__setattr__(key, value)

def _convert_mutable_datatypes():
    print(" got to this line")
    return 10


if __name__ == "__main__":
    st = State()
    st.add()
